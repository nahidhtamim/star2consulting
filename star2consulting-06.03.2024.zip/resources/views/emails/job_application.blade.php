<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Application</title>
</head>
<body>
    <p>Hello HR Department,</p>
    <p>You have received a new job application from {{ $name }}.</p>
    <p>Cover Letter:</p>
    <p>{{ $coverLetter }}</p>
    <p>Kind regards,</p>
    <p>{{ $name }}</p>
</body>
</html>
