<p> 

    #44552641
   
   
    => CREDIT REMOVAL LICENSE FOR ALL FREE TEMPLATES BY HTML Codex
   
    This license grants you or the purchaser an ongoing, non-exclusive, worldwide license to make use of our all free templates without the author�s credit under the following conditions.
   
   
    => YOU ARE ALLOWED
   
         1. You are allowed to use without the footer author�s credit link/attribution link/backlink.
   
         2. You are allowed to use for your personal and commercial purposes.
   
         3. You are allowed to modify/customize however you like.
   
         4. You are allowed to convert/port for use for any CMS.
   
         5. You are allowed to share/distribute under the HTML Codex brand name.
   
         6. You are allowed to put a screenshot or a link on your blog posts or any other websites.
   
   
    => YOU ARE NOT ALLOWED
   
         1. You are not allowed to sell, resale, rent, lease, license, or sub-license.
   
         2. You are not allowed to upload on your template websites or template collection websites or any other third party websites without our permission.
   
   
    => If a template contains premium stock photos which are only for demo purposes and not distributed with the template. You need to purchase them separately from the corresponding stock photo website. You are responsible for adhering to the original license of them if necessary.
   
   
    => This license can be terminated if you breach any of these conditions.
   
   
    Please contact us (https://htmlcodex.com/contact) if you have any query.</p>