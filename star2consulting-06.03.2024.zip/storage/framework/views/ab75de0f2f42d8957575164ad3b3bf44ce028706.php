<?php $__env->startSection('title'); ?>
Edit Blog | Star 2 Consulting Inc.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin_content'); ?>


<!-- blog Heading -->
<div class="text-center">
    <h1 class="h3 mb-0 text-gray-800 text-center" >Edit Blog</h1>
</div>
<hr>
<?php if(session('status')): ?>
<div class="alert alert-success"><?php echo e(session('status')); ?></div>
<?php endif; ?>
<!-- Content Row -->
<div class="row">
    <div class="col-10 m-auto">
        <!-- DataTales Example -->
        <div class="card bg-light shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Blog</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('update.blog', ['id' => $blog->id] )); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="title"> <b>Title<span class="text-danger">*</span></b> </label>
                        <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($blog->title); ?>" required>
                        <span class="text-danger">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>
                    <br>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="description" class="form-label"><b>Description<span class="text-danger">*</span></b></label>
                            <textarea name="description" class="form-control description <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" cols="30" rows="5" placeholder="Write a description" required><?php echo e($blog->description); ?></textarea>
                            <span class="text-danger">
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span> 
                        </div>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="media"> <b>Media</b> <sup>[Size: To maintain the design, please use image of same
                                size
                                ]</sup></label>
                        <input type="file" name="media" class="form-control" accept="">
                        <br>
                        <?php
                            $extension = pathinfo($blog->media, PATHINFO_EXTENSION);
                        ?>

                        <?php if(in_array($extension, ['mp4', 'mkv'])): ?>
                            <video controls height="150px" width="220px">
                                <source src="<?php echo e(asset('upload/blog/'.$blog->media)); ?>" type="">
                            </video>
                        <?php elseif(in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                            <img src="<?php echo e(asset('upload/blog/'.$blog->media)); ?>" alt="" height="150px" width="220px">
                        <?php else: ?>
                            <p>Unsupported media type</p>
                        <?php endif; ?>
                        
                    </div>
                    <br>
                    <div class="form-group text-right">
                        <input type="submit" value="Save" class="btn btn-success">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\star2consulting\resources\views/admin/blog/edit-blog.blade.php ENDPATH**/ ?>