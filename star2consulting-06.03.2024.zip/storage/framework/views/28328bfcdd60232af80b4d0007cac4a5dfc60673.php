
<?php $__env->startSection('title'); ?>
<?php echo e($privacy_text->title); ?> | Star 2 Consulting Inc.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Services Start -->
<div class="container-fluid service bg-light section-padding">
    <div class="container py-5">
        <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.2s">
            <span><?php echo $privacy_text->description; ?></span>
        </div>

    </div>
</div>
<!-- Services End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\star2consulting\resources\views/privacy.blade.php ENDPATH**/ ?>