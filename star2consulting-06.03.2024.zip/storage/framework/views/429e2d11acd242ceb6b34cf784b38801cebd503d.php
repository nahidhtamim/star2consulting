
<?php $__env->startSection('title'); ?>
Powerskills | Star 2 Consulting Inc.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Feature Start -->
<div class="container-fluid feature bg-light section-padding">
    <div class="container py-5">
        <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.1s">
            <h1 class="display-3 mb-4">Leadership skills</h1>
        </div>

        <div class="row g-4 justify-content-center">
            <?php $__currentLoopData = $leader_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp mx-auto" data-wow-delay="0.1s">
                <div class="row-cols-1 feature-item p-4">
                    <div class="col-12">
                        <div class="feature-icon mb-4">
                            <div class="p-3 d-inline-flex bg-white rounded">
                                <i class="<?php echo e($leader->icon); ?> fa-4x text-primary"></i>
                            </div>
                        </div>
                        <div class="feature-content d-flex flex-column">
                            <h5 class="mb-4"><?php echo e($leader->title); ?></h5>
                            <p class="mb-0"><?php echo $leader->description; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
         <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.1s">
            <h1 class="display-3 my-4">Powerskills</h1>
        </div>
        
        <div class="row g-4 justify-content-center">
            <?php $__currentLoopData = $power_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $power): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp mx-auto" data-wow-delay="0.1s">
                <div class="row-cols-1 feature-item p-4">
                    <div class="col-12">
                        <div class="feature-icon mb-4">
                            <div class="p-3 d-inline-flex bg-white rounded">
                                <i class="<?php echo e($power->icon); ?> fa-4x text-primary"></i>
                            </div>
                        </div>
                        <div class="feature-content d-flex flex-column">
                            <h5 class="mb-4"><?php echo e($power->title); ?></h5>
                            <p class="mb-0"><?php echo $power->description; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
</div>
<!-- Feature End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\star2consulting\resources\views/powerskills.blade.php ENDPATH**/ ?>