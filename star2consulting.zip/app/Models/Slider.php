<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    use HasFactory;

    protected $table = 'Sliders';

    protected $fillable = [
        'image',
        'key_point',
        'title',
        'description',
        'status',
    ];
}
