@extends('layouts.admin')
@section('title')
Admin Dashboard | Star 2 Consulting Inc.
@endsection
@section('admin_content')
<div class="container-fluid pt-2">
    <div class="row my-5 py-5">
        <div class="col-md-12 my-5 py-5 text-center">
            <h1>Welcome To Star 2 Consulting Inc <br> Admin Dashboard</h1>
        </div>
    </div>
</div>

@endsection
