
<?php $__env->startSection('title'); ?>
Solutions | Star 2 Consulting Inc.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- Services Start -->
<div class="container-fluid service bg-light section-padding">
    <div class="container py-5">
        <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.2s">
            <!-- <div class="sub-style">
                <h4 class="sub-title px-3 mb-0">Solutions</h4>
            </div> -->
            <h1 class="display-3 mb-4"><?php echo $solution_first_text->description; ?></h1>
            <p class="mb-0"><?php echo $solution_second_text->description; ?></p>
        </div>
        <div class="row g-4">
            <div class="solutions-carousel owl-carousel">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="service-item rounded" style="box-shadow: unset;">
                    <div class="service-img rounded-top">
                        <img src="<?php echo e(asset('upload/product/'.$product->image)); ?>" class="img-fluid rounded-top w-100" alt="">
                    </div>
                    <div class="service-content rounded-bottom bg-secondary p-4">
                        <div class="service-content-inner">
                            <h5 class="mb-4"><?php echo e($product->name); ?></h5>
                            <p class="mb-4"><?php echo substr($product->description, 0, 120)."......"; ?></p>
                            <a href="<?php echo e(route('solution.details', ['slug' => $product->slug] )); ?>" class="btn btn-primary rounded-pill text-white py-2 px-4 mb-2">Read More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>
<!-- Services End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\star2consulting\resources\views/solutions.blade.php ENDPATH**/ ?>