
<?php $__env->startSection('title'); ?>
Admin Dashboard | Star 2 Consulting Inc.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin_content'); ?>
<div class="container-fluid pt-2">
    <div class="row my-5 py-5">
        <div class="col-md-12 my-5 py-5 text-center">
            <h1>Welcome To Star 2 Consulting Inc <br> Admin Dashboard</h1>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\star2consulting\resources\views/admin/admin-dashboard.blade.php ENDPATH**/ ?>