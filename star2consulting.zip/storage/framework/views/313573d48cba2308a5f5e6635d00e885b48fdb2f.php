
<?php $__env->startSection('title'); ?>
Vision | Star 2 Consulting Inc.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- About Start -->
<div class="container-fluid about bg-light section-padding">
    <div class="container py-5">
        <div class="row g-5 align-items-center">
            <div class="col-lg-5 wow fadeInLeft" data-wow-delay="0.2s">
                <div class="about-img pb-5 ps-5">
                    <img src="<?php echo e(asset('upload/web_content/'.$vision_text->media)); ?>" class="img-fluid rounded w-100" style="object-fit: cover;" alt="Image">
                </div>
            </div>
            <div class="col-lg-7 wow fadeInRight" data-wow-delay="0.4s">
                <div class="section-title text-start mb-5">
                    <h1 class="display-3 mb-4"><?php echo e($vision_text->title); ?></h1>
                    <span class="mt-3"><?php echo $vision_text->description; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\star2consulting\resources\views/vision.blade.php ENDPATH**/ ?>