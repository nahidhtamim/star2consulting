
<?php $__env->startSection('title'); ?>
Insights | Star 2 Consulting Inc.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- Blog Start -->
<div class="container-fluid blog bg-light section-padding">
    <div class="container py-5">
        <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.1s">
            <div class="sub-style">
                <h4 class="sub-title px-3 mb-0">Our Blog</h4>
            </div>
            <h1 class="display-3 mb-4">Research and Access to Blogs </h1>
            <!-- <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat deleniti amet at atque sequi quibusdam cumque itaque repudiandae temporibus, eius nam mollitia voluptas maxime veniam necessitatibus saepe in ab? Repellat!</p> -->
        </div>
        <div class="row g-4 justify-content-center">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $createdAt = \Carbon\Carbon::parse($blog->created_at);
                $now = \Carbon\Carbon::now();

                // Calculate the difference
                $diff = $createdAt->diff($now);

                // Access individual components of the difference
                $days = $diff->days;
                $hours = $diff->h;
                $minutes = $diff->i;
                $seconds = $diff->s;
            ?>

            <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
                <div class="blog-item rounded">
                    <div class="blog-img">
                        <?php
                            $extension = pathinfo($blog->media, PATHINFO_EXTENSION);
                        ?>

                        <?php if(in_array($extension, ['mp4', 'mkv'])): ?>
                            <video controls class="img-fluid w-100" alt="Image">
                                <source src="<?php echo e(asset('upload/blog/'.$blog->media)); ?>" type="">
                            </video>
                        <?php elseif(in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                            <img src="<?php echo e(asset('upload/blog/'.$blog->media)); ?>" alt=""class="img-fluid w-100" alt="Image">
                        <?php else: ?>
                            <p>Unsupported media type</p>
                        <?php endif; ?>
                    </div>
                    <div class="blog-centent p-4">
                        <div class="d-flex justify-content-between mb-4">
                            <p class="mb-0 text-muted">
                                <i class="fa fa-calendar-alt text-primary"></i>
                                <?php if($diff->days > 0): ?>
                                Posted: <?php echo e($days); ?> days ago
                                <?php elseif($diff->h > 0): ?>
                                Posted: <?php echo e($hours); ?> hours ago
                                <?php elseif($diff->i > 0): ?>
                                Posted: <?php echo e($minutes); ?> minutes ago
                                <?php else: ?>
                                Posted: <?php echo e($seconds); ?> seconds ago
                                <?php endif; ?>
                            </p>
                        </div>
                        <a href="#" class="h4"><?php echo e($blog->title); ?></a>
                        <p class="my-4"><?php echo substr($blog->description, 0, 120)."......"; ?></p>
                        <a href="#" class="btn btn-primary rounded-pill text-white py-2 px-4 mb-1">Read More</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Blog End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\star2consulting\resources\views/blog.blade.php ENDPATH**/ ?>